#ifndef AFFICH_H_INCLUDED
#define AFFICH_H_INCLUDED
#include "defineStruct.h"

extern void AffichageInit(char tab[HEIGHTAB][WIDTHTAB]);
extern void AffichageTrace(int tabTrace[HEIGHTAB][WIDTHTAB],char tabAff[HEIGHTAB][WIDTHTAB]);

#endif // AFFICH_H_INCLUDED
