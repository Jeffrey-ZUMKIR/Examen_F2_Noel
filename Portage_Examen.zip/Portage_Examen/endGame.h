#ifndef ENDGAME_H_INCLUDED
#define ENDGAME_H_INCLUDED

extern void CheckEndGame(str_monstre monstre,str_pisteur tabPisteur[],int *good, int nbPisteur);

#endif // ENDGAME_H_INCLUDED
