#ifndef TRACE_H_INCLUDED
#define TRACE_H_INCLUDED
#include "defineStruct.h"

extern void deleteTrace(int mapTraceMonstre[HEIGHTAB][WIDTHTAB]);




#endif // TRACE_H_INCLUDED
