#ifndef VOIDSDL_H_INCLUDED
#define VOIDSDL_H_INCLUDED
#include "defineStruct.h"

extern void AffichImgSDL(SDL_Renderer *pRenderer,listTexture myTexture,int tabTrace[HEIGHTAB][WIDTHTAB],char tabAff[HEIGHTAB][WIDTHTAB]);

#endif // VOIDSDL_H_INCLUDED
